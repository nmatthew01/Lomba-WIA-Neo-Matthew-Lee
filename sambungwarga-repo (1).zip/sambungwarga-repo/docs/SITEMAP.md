# SambungWarga: Sitemap and Wireframes

## Sitemap

```mermaid
flowchart TD
  A[Top bar: Search · Settings ⚙️ · Notifications 🔔 · Sign in] --> H
  H[Home] --> V[How we verify what you see]
  H --> I[Important information near you]
  H --> M1[Emergency Mode]
  H --> M2[Public Services]
  H --> M3[Civic Reports]
  M1 --> E1[6 categories + call buttons]
  M1 --> E2[Assistance flow per category: situation, call, simulated request, advice while waiting]
  M1 --> E3[Alarm · My contact · GPS · Offline notes]
  M2 --> S1[Find help for me: neighborhood + need]
  M2 --> S2[Projects and services + detail + follow]
  M2 --> S3[Community requests + apply]
  M3 --> R1[Report list + filters]
  M3 --> R2[Report detail: Summary · Progress · Photos · Comments]
  M3 --> R3[Report a problem · Crime reports · Private tips]
  M3 --> R4[Open data download CSV]
  A --> ST[Settings: personalization · language · emergency contact · account]
  A --> AC[My account: notifications · my reports · points]
  A --> AD[Admin dashboard: analytics · moderation · rewards · users · audit log]
```

| Area | Who can open it | Works offline |
|---|---|---|
| Home, Services, Reports | Everyone (actions need sign-in) | No |
| Emergency Mode | Everyone, no account | **Yes** |
| Settings | Everyone | **Yes** |
| My account | Signed-in users | No |
| Admin dashboard | Moderator and above | No |

## Wireframes (low fidelity)

### Home (desktop)
```
+----------------------------------------------------------------------+
| Logo  [ Search reports, services, places ]     ⚙️  🔔  Sign in       |
| [Home] [Emergency] [Services] [Reports]                              |
| +--------------------------------------------------+ 📍 Menteng      |
| | 🙂 Hello, neighbor!                              | Change location |
| +--------------------------------------------------+                 |
| [ 🚨 Emergency Mode →] [ 🏛️ Public Services →] [ 📣 Civic Reports →] |
| Important information near you      [All][Emergency][Services]...    |
| [card][card][card][card]                                             |
| How we verify what you see:  1 Submitted > 2 Reviewed > 3 Verified   |
|                              > 4 Tracked > 5 Resolved & verified     |
| [Recent activity]                    [Available on every device]     |
+----------------------------------------------------------------------+
```

### Home (phone)
```
+------------------+
| Logo      ⚙️ 🔔 ⎋ |
| Hello, neighbor! |
| 📍 Menteng       |
| [🚨 Emergency  →]|
| [🏛️ Services   →]|
| [📣 Reports    →]|
| chips ← →        |
| info cards       |
+------------------+
|🏠  🚨  🏛️  📣  👤|   <- bottom tabs, 44px+ targets
+------------------+
```

### Report detail
```
+-------------------------------------------+
| Road damage, Jl. Merdeka     [+ Follow]   |
| [Report: Verified] [Repair: In progress]  |
| [Summary][Progress][Photos][Comments]     |
|  ● Oct 30 Work in progress   OFFICIAL     |  <- latest highlighted
|  ● Oct 29 Work assigned      OFFICIAL     |
|  ● Oct 28 Inspection         VERIFIED     |
|  ● Oct 27 Report received    COMMUNITY    |
+-------------------------------------------+
```

### Admin analytics
```
+---------------------------------------------------------+
| [Reports][Unresolved][Resolved %][Delayed][Awaiting]    |
| [By category bars]        [By stage bars]               |
| [Open by neighborhood]    [Needs attention list]        |
| [Download open data (CSV)]                              |
| [Moderation queue] [Reward approvals] [Users] [Audit]   |
+---------------------------------------------------------+
```
